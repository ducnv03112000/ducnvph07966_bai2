import {Product} from 'product';
export const data: Product[]=[
  {id:1, name: 'cá', price: '3',img:'https://dailam.com.vn/wp-content/uploads/2019/04/cachep.jpg',desc:'Cá tươi ngon'},
  {id:2, name: 'tôm', price: '5',img:'https://daubepgiadinh.vn/wp-content/uploads/2019/01/luoc-tom-ngon-voi-sa-600x400.jpg',desc:'tôm tươi ngon'},
  {id:3, name: 'thịt ngựa', price: '4',img:'https://toanbds.com/wp-content/uploads/2018/11/Ng%E1%BB%B1a-%C4%91ua-696x464.jpg',desc:'thịt ngựa ngon'},
  {id:5, name: 'thịt trâu', price: '3',img:'https://188loto.com/wp-content/uploads/2019/10/mo-thay-trau-danh-con-gi-4.jpg',desc:'thịt trâu ngon'},
  {id:5, name: 'thịt gà', price: '6',img:'https://suckhoedoisong.vn/Images/nguyenkhanh/2017/01/20/ga_trong_y_duoc.jpg',desc:'thịt gà tươi ngon'},
  {id:6, name: 'thịt lợn', price: '7',img:'https://vtv1.mediacdn.vn/thumb_w/800/2018/10/13/con-lon-crop-1539366856272166690165.jpg',desc:'thịt lợn tươi ngon'},
  {id:7, name: 'thịt vịt', price: '3',img:'https://upload.wikimedia.org/wikipedia/commons/c/c1/Duck_on_Yeadon_Tarn_%2813th_November_2010%29_002.jpg',desc:'thịt vịt tươi ngon'},
  {id:8, name: 'thịt ngan', price: '2',img:'https://traigiongthuha.com/uploads/news/size610/news1/3/news_298.jpg',desc:'thịt ngan tươi ngon'},
  {id:9, name: 'đậu phụ', price: '1',img:'https://i.ytimg.com/vi/-Toue02cf3k/maxresdefault.jpg',desc:'đậu phụ tươi ngon'},
  {id:10, name: 'rau', price: '1',img:'https://cafefcdn.com/thumb_w/650/2019/2/20/rau-la-xanh-dam-cung-chua-nhieu-vitamin-a-15506352446131206048336-crop-15506352499031239676889.jpg',desc:'rau tươi ngon'},


  
]