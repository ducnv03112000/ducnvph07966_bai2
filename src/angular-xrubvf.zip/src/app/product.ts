export class Product {
 id: number;
 name: String;
 price: String;
 img:String;
 desc : String; 
} 